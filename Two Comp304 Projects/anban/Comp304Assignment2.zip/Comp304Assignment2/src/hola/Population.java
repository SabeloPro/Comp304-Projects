package hola;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;


public class Population {
   private ArrayList<Chromosome> population;

   private ArrayList<Chromosome>matingPool;

   private static final float mutationRate = 0.1f;
   private static final float crossoverRAte= 0.85f;

   public Population(Scanner scanner, int populationSize) {
       population= new ArrayList<>();
       Chromosome chromosome = new Chromosome(scanner);
       for (int j = 0; j <populationSize; j++) {
           Chromosome chromosome1 = chromosome;
           for (Gene g: chromosome1.getGenes()) {
               int load = new Random().nextInt(2);
               if(load==1)
                   g.setLoadBox(1);
           }

           population.add(chromosome1);
           chromosome.neutralize();
       }
       matingPool = new ArrayList<>();
       matingPool.addAll(population);

   }

   public ArrayList<Chromosome> getPopulation() {
            return population;
        }

    public ArrayList<Chromosome> getMatingPool() {
        for (int i = 0; i <getPopulation().size() ; i++) {
             if(getPopulation().get(i).isFit()==1){
                 matingPool.add(getPopulation().get(i));
                 matingPool.add(getPopulation().get(i));
             }
             else{
                 matingPool.add(getPopulation().get(i));
             }
        }
       return matingPool;
    }

    public Chromosome selection(){
        int selectIndex = (int)(Math.random()*getMatingPool().size());
        Chromosome selectedChromosome = matingPool.get(selectIndex);
        population.remove(matingPool.get(selectIndex));
        return selectedChromosome;
    }

    public void setPopulation(ArrayList<Chromosome> population) {
        this.population = population;
    }

    public  Chromosome crossover(Chromosome parent1, Chromosome parent2){
       Chromosome child = new Chromosome();
        float cross= new Random().nextFloat();
        int breakpoint = new Random(1).nextInt(parent1.getSize());
        if(cross<crossoverRAte) {
            for (int i = 0; i < parent1.getSize(); i++) {
                if (i <= breakpoint)
                    child.getGenes().add(parent1.getGene(i));
                else
                    child.getGenes().add(parent2.getGene(i));
            }
            child.setCapacity(parent1.getCapacity());
            child.setQuoter(parent1.getQuoter());
            return child;
        }
        return parent1;
    }

    public Chromosome mutation(Chromosome chromosome){
       float mutate = new Random().nextFloat();
       if(mutate>mutationRate){
            int randomIndex = new Random().nextInt(chromosome.getSize());
            if (chromosome.getGene(randomIndex).getLoadBox()==1)
                chromosome.getGene(randomIndex).setLoadBox(0);
            else
                chromosome.getGene(randomIndex).setLoadBox(1);

            return chromosome ;
        }
        return chromosome;
    }

    public String toString(){
            String string = "";
            for (Chromosome c : getPopulation()) string += c.toBinaryRepresentation() +" Total Weight: "+c.getTotalWeight()+" Total Value: "+c.getTotalValue()+"\n";
            return string;
    }
}

package hola;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static int problemNumber = 1;
    public static void main(String[] args) throws FileNotFoundException {
	// write your code here

        Scanner input = new Scanner(System.in);
        System.out.println("\nPlease Enter a number as an option you prefer");
        System.out.println("1.Use MyTesting File\n2.Use your own Testing File");
        int option = input.nextInt();
        Scanner scanner = null;
        if(option==1) {
            scanner = new Scanner(new File("TestData.txt"));
        }
        else if(option==2) {
            System.out.print("Enter your file name(include the file extension)/  full file path:");
            String filename = input.next();
            scanner = new Scanner(new File(filename));
        }
        else{
            System.out.println("Invalid option please reRun the program");
            System.exit(0);
        }
        while(scanner.hasNext()){
            GeneticAlgorthm ga = new GeneticAlgorthm(scanner,10);
            ga.runGA();
            problemNumber++;
        }
        scanner.close();
    }
}

package hola;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class Chromosome{
   private ArrayList<Gene> genes ;
    private int quoter,capacity;
    int numberOfObjects;

    public Chromosome(ArrayList<Gene>genes){
           this.genes =genes;
    }

    public Chromosome(Scanner sc){
        genes = new ArrayList<>();
        sc.next();
        this.capacity = sc.nextInt();//Integer.parseInt(sc.nextLine());
        this.quoter = sc.nextInt();//Integer.parseInt(sc.nextLine());
        numberOfObjects = sc.nextInt();// Integer.parseInt(sc.nextLine());
        for (int i = 0; i < numberOfObjects; i++) {
            String name = sc.next();
            int weight = sc.nextInt();// Integer.parseInt(String.valueOf(sc.nextInt()));
            int value = sc.nextInt();// Integer.parseInt(String.valueOf(sc.nextInt()));
            genes.add(i,new Gene(name, weight, value));
        }
    }
    public  void neutralize(){
        for (Gene g:genes){
             if(g.getLoadBox()==1)
                 g.setLoadBox(0);
        }

    }
    public  Chromosome(){this.genes = new ArrayList<>();}

    public Gene getGene(int index){
        return genes.get(index);
    }

    public void swap(int index1,int index2){
        Gene temp1 = genes.get(index1);
        Gene temp2 = genes.get(index2);
        genes.remove(index1);
        genes.remove(index2);
        genes.add(index1,temp2);
        genes.add(index2,temp1);

    }

    public int getTotalWeight(){
        int totalW =0;
        for (Gene g:genes) {
            if(g.getLoadBox()==1)
                totalW+=g.getWeight();
        }
        return totalW;
    }

    public int getTotalValue(){
        int totalV =0;
        for (Gene g:genes) {
            if(g.getLoadBox()==1)
                totalV+=g.getValue();
        }
        return totalV;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setQuoter(int quoter) {
        this.quoter = quoter;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getQuoter() {
        return quoter;
    }

    public ArrayList<Gene> getGenes() {
        return genes;
    }

    public String toString(){
        String chromosome ="[ ";
        for (Gene g: genes) {
            chromosome+=g.getName()+" ";
        }
        chromosome+="]";
        return chromosome;
    }

    public int isFit(){
        return getTotalWeight()<=capacity?1:0;
    }

    public String toBinaryRepresentation(){
        System.out.println("Binary Representation");
        System.out.println(toString());
        String s = "[ ";
        for (int i = 0; i <getSize(); i++) {
            s+=getGene(i).getLoadBox()+" ";
        }
        return s+"]";
    }
    public  String showLoaded(){
        String loaded = "{ ";
        for (int i = 0; i < this.getGenes().size(); i++) {
            if(this.getGene(i).getLoadBox()==1){
                loaded+=getGene(i).getName()+" ";
            }
        }
        return loaded+"} Its "+"Total Weight: "+ getTotalWeight()+", its Total Value: "+getTotalValue();
    }
    public int getSize() {
        return genes.size();
    }
}

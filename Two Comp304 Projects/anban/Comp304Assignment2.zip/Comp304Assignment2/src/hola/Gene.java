package hola;

public class Gene {
    private String name;
    private int  value ,weight,loadBox;


    public Gene(String name,int weight,int value){
        this.name =name;
        this.weight =weight;
        this.value =value;
    }
    public String getName(){
        return name;
    }

    public int getValue(){
        return value;
    }

    public int getWeight(){
        return weight;
    }

    public int getLoadBox() {
        return loadBox;
    }

    public void setLoadBox(int loadBox) {
        this.loadBox = loadBox;
    }

    public String toString(){
        return ""+getName()+" "+getWeight()+" "+getValue();
    }

}

package hola;

import java.util.ArrayList;
import java.util.Scanner;

public class GeneticAlgorthm {
    private Population p;
    private int generation;
    public GeneticAlgorthm(Scanner scanner, int initialPopulationSize){
          p = new Population(scanner,initialPopulationSize);
          generation =0;
    }
    public boolean terminationCriteria(Population p){
        for (Chromosome c: p.getPopulation())
            return c.getTotalWeight()<=c.getCapacity() && c.getTotalValue()>=c.getQuoter();
        return false;
    }

    public Population getP() {
        return p;
    }

    public int getGeneration() {
        return generation;
    }

    public void setGeneration(int generation) {
        this.generation = generation;
    }

    public void  runGA(){

        while(!terminationCriteria(p)){
            generation++;
            ArrayList<Chromosome> pop = new ArrayList<>();

            for (int i = 0;i<p.getPopulation().size()/2;i++){
                // Select parents
                Chromosome parent1 = p.selection();
                Chromosome parent2 = p.selection();

                //Cross over
                Chromosome child1 =  p.crossover(parent1,parent2);
                Chromosome child2 = p.crossover(parent2,parent1);

                // mutation
                child1 = getP().mutation(child1);
                child2 = getP().mutation(child2);
                pop.add(child1);
                pop.add(child2);
            }
            p.setPopulation(pop);

        }
        System.out.println("Solution found for Problem "+ Main.problemNumber+" is: ");
        for (Chromosome c:p.getPopulation()) {
            if(c.getTotalWeight()<=c.getCapacity() && c.getTotalValue()>=c.getQuoter())
                 System.out.println(c.showLoaded());
                 System.out.println(c.toBinaryRepresentation());
                 System.out.println("Was found in Generation "+getGeneration()+"\n");
                    break;
                }

        }
}

